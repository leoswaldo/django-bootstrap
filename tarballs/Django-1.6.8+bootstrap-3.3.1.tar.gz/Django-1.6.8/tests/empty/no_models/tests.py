from django.test import TestCase


class NoModelTests(TestCase):
    """ A placeholder test case. See empty.tests for more info. """
    pass
